# Ссылка на готовый [сайт](https://shramkoweb.github.io/Mishka/) «Мишка»

***
- Flex-box
- Gulp & Sass
- Adaptive: **320px, 768px, 1150px**
- BEM
- Ретинизация растровой графики 
- Оптимизация графики: **кадрирование контентных изображений, svg-sprite, WebP**
- Оптимизация загрузки шрифтов
- Адаптивность: **Chrome, Opera, Firefox, Safari, Edge, а также в Internet Explorer 11.**
- JavaScript меню и pop-up
---
